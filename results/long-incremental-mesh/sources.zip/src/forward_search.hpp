#pragma once
#include "indexed_open.hpp"

// Prefix labels only order the search. At a primitive endpoint the parent is
// always a pose, so the same reconstruction works for a normal edge or a jump.
class ForwardSearch {
    struct Label {
        Cost distance = Cost::inf();
        Node parent = -1;
        Edge incoming{};
        HeapSlot slot;
    };
    Node start;
    std::unordered_map<Node, Label> labels;
    IndexedOpen open;
    QueueOps &ops;

public:
    ForwardSearch(Node robot, Cost estimate, QueueOps &ops) : start(robot), ops(ops) {
        Label &label = labels[start];
        label.distance = {};
        open.set(start, {estimate, estimate}, label.slot, ops);
    }
    bool empty() const { return open.empty(); }
    Node pop() { return open.pop(ops).first; }
    Cost distance(Node u) const {
        auto found = labels.find(u);
        return found == labels.end() ? Cost::inf() : found->second.distance;
    }
    void relax(Node parent, Edge edge, Cost g, Cost h) {
        Label &label = labels[edge.node];
        if (!(g < label.distance)) return;
        label.distance = g;
        label.parent = parent;
        label.incoming = edge;
        open.set(edge.node, {g + h, h}, label.slot, ops);
    }
    std::vector<Edge> path(Node u) const {
        std::vector<Edge> result;
        while (u != start) {
            const Label &label = labels.at(u);
            result.push_back(label.incoming);
            u = label.parent;
        }
        std::reverse(result.begin(), result.end());
        return result;
    }
};
