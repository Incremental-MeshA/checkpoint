#pragma once
#include "planner.hpp"

// The label owns its slot. unordered_map keeps label addresses stable on rehash.
// A node can change key in either direction or leave OPEN before being popped.
struct HeapSlot {
    static constexpr size_t absent = std::numeric_limits<size_t>::max();
    size_t index = absent;
};

class IndexedOpen {
    struct Entry {
        Key key;
        Node node;
        HeapSlot *slot;
        bool operator<(const Entry &other) const {
            return std::tie(key, node) < std::tie(other.key, other.node);
        }
    };
    std::vector<Entry> heap;

    void exchange(size_t a, size_t b) {
        std::swap(heap[a], heap[b]);
        heap[a].slot->index = a;
        heap[b].slot->index = b;
    }
    void up(size_t i) {
        while (i && heap[i] < heap[(i - 1) / 2]) {
            size_t parent = (i - 1) / 2;
            exchange(i, parent);
            i = parent;
        }
    }
    void down(size_t i) {
        while (2*i + 1 < heap.size()) {
            size_t child = 2*i + 1;
            if (child + 1 < heap.size() && heap[child + 1] < heap[child]) ++child;
            if (!(heap[child] < heap[i])) break;
            exchange(i, child);
            i = child;
        }
    }
    void remove_at(size_t i) {
        exchange(i, heap.size()-1);
        heap.back().slot->index = HeapSlot::absent;
        heap.pop_back();
        if (i == heap.size()) return;
        if (i && heap[i] < heap[(i-1)/2]) up(i);
        else down(i);
    }

public:
    bool empty() const { return heap.empty(); }
    Key minimum(QueueOps &ops) const {
        ++ops.peek;
        return heap.empty() ? Key{Cost::inf(), Cost::inf()} : heap.front().key;
    }
    void set(Node n, Key key, HeapSlot &slot, QueueOps &ops) {
        size_t i = slot.index;
        if (i == HeapSlot::absent) {
            ++ops.insert;
            slot.index = heap.size();
            heap.push_back({key,n,&slot});
            up(slot.index);
            return;
        }
        Key old = heap[i].key;
        if (old == key) return;
        ++ops.change;
        heap[i].key = key;
        if (key < old) up(i);
        else down(i);
    }
    void erase(HeapSlot &slot, QueueOps &ops) {
        if (slot.index != HeapSlot::absent) {
            ++ops.erase;
            remove_at(slot.index);
        }
    }
    std::pair<Node,Key> pop(QueueOps &ops) {
        ++ops.pop;
        auto first = std::make_pair(heap.front().node, heap.front().key);
        remove_at(0);
        return first;
    }
};
