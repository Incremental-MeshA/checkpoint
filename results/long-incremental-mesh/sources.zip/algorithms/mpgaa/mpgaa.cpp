#include "../../src/changed_edges.hpp"
#include "../../src/forward_search.hpp"

namespace {
// Adaptive estimates and cached paths belong to complete poses. Mesh prefixes
// borrow the estimates of their possible endpoints (Finals). This also lets
// cost-decrease repair work on whole motions without expanding prefix trees.
class MPGAA final : public Planner {
    struct Learned {
        Cost h;
        HeapSlot repair_slot;
    };
    std::vector<Config> motions;
    ChangedEdgeIndex raised;
    std::unordered_map<Node, Learned> learned;
    std::unordered_map<Node, Edge> policy;
    std::vector<double> geometric;

    Cost motion_cost(int i) const {
        const Primitive &p = graph.primitives[i];
        Cost cost = p.length;
        cost.steps = graph.is_mesh() ? static_cast<int>(p.trace.size()) - 1 : 1;
        return cost;
    }
    std::vector<Config> pose_transitions() const {
        std::vector<Config> poses(16);
        for (int i = 0; i < static_cast<int>(graph.primitives.size()); ++i) {
            const Primitive &p = graph.primitives[i];
            int slot = static_cast<int>(poses[p.start].out.size());
            poses[p.start].out.push_back({p.end, p.delta, i, motion_cost(i), slot, -2});
            poses[p.end].in.push_back({p.start, Point{} - p.delta, i, motion_cost(i), slot, -2});
        }
        return poses;
    }
    Cost heuristic(Node pose) {
        auto it = learned.find(pose);
        if (it != learned.end()) return it->second.h;
        double &value = geometric[graph.cell(pose)];
        if (value < 0) value = graph.forward(pose, goal).value();
        return Cost::length(value);
    }

    void repair(const Batch &batch, Metrics &m) {
        auto began = Metrics::Clock::now();
        std::unordered_map<Node, Cost> seeds;
        raised.visit(batch, [&](Node u, Edge edge, EdgeChange) {
            Cost bound = edge.cost + heuristic(edge.node);
            if (bound < learned.at(u).h) {
                auto it = seeds.emplace(u, bound).first;
                it->second = std::min(it->second, bound);
            }
        });
        m.changed_edges_ms = Metrics::since(began);
        m.batch_seeds = seeds.size();
        IndexedOpen queue;
        auto lower = [&](Node pose, Cost bound, Learned &label) {
            label.h = bound;
            queue.set(pose, {bound, {}}, label.repair_slot, m.repair);
        };
        for (auto [pose, bound] : seeds) {
            m.record(graph, pose, Metrics::Seed);
            lower(pose, bound, learned.at(pose));
        }
        // Only previously raised predecessors can violate consistency. Test their
        // bound before touching the grid or walking their collision trace.
        while (!queue.empty()) {
            Node u = queue.pop(m.repair).first;
            ++m.repair_expanded;
            m.repair_cells.insert(graph.cell(u));
            m.record(graph, u, Metrics::Repair);
            Cost h = learned.at(u).h;
            if (h == graph.forward(u, goal)) {
                raised.forget(u);
                learned.erase(u); // popped; OPEN no longer holds its slot
            }
            Point target = graph.point(u);
            for (const Arc &arc : motions[graph.type(u)].in) {
                Point source = target + arc.delta;
                if (!graph.grid.contains(source)) continue;
                Node pred = graph.at(source, arc.type);
                auto it = learned.find(pred);
                if (it == learned.end()) continue;
                Cost bound = arc.cost + h;
                if (bound < it->second.h && graph.traversable(source, target, arc.primitive, -2))
                    lower(pred, bound, it->second);
            }
        }
    }

    Result suffix(Node u, std::unordered_set<Node> &invalid) {
        Result result{true, {}};
        Node first = u;
        while (u != goal) {
            auto it = policy.find(u);
            if (it == policy.end() || invalid.count(u)) break;
            const Edge &edge = it->second;
            if (heuristic(u) != edge.cost + heuristic(edge.node) ||
                !graph.traversable(graph.point(u), graph.point(edge.node), edge.primitive, -2))
                break;
            result.path.push_back(edge);
            u = edge.node;
        }
        if (u == goal) return result;
        if (!result.path.empty()) {
            invalid.insert(first);
            for (const Edge &edge : result.path) invalid.insert(edge.node);
        }
        return {};
    }

    void finish_motion(ForwardSearch &search, Node end, int i, Cost g) {
        if (!(g < search.distance(end))) return;
        const Primitive &p = graph.primitives[i];
        Node origin = graph.at(graph.point(end) - p.delta, p.start);
        search.relax(origin, {end, motion_cost(i), i, -1, -2}, g, heuristic(end));
    }
    void consider_prefix(ForwardSearch &search, Node prefix, Cost g) {
        if (!(g < search.distance(prefix))) return;
        const Config &config = graph.configurations()[graph.type(prefix)];
        Point origin = graph.point(prefix) - config.offset;
        Cost best = Cost::inf();
        int count = 0, only = -1;
        Node only_end = -1;
        Cost only_distance;
        for (int i : config.completions) {
            const Primitive &p = graph.primitives[i];
            Point target = origin + p.delta;
            if (!graph.grid.contains(target) || graph.grid.occupied(graph.grid.cell(target))) continue;
            Node end = graph.at(target, p.end);
            Cost remaining = motion_cost(i);
            remaining.steps -= config.depth;
            Cost arrival = g + remaining;
            // This query already has an equally good or cheaper route to end.
            if (!(arrival < search.distance(end))) continue;
            best = std::min(best, remaining + heuristic(end));
            ++count;
            only = i;
            only_end = end;
            only_distance = arrival;
        }
        if (count == 0) return;
        if (count == 1) {
            // The common prefix has already passed collision checks. When a
            // single final remains, validate its tail once and skip its OPEN work.
            const auto &trace = graph.primitives[only].trace;
            for (size_t k = config.depth + 1; k < trace.size(); ++k) {
                Point cell = origin + trace[k];
                if (!graph.grid.contains(cell) || graph.grid.occupied(graph.grid.cell(cell))) return;
            }
            finish_motion(search, only_end, only, only_distance);
        } else {
            search.relax(-1, {prefix, {}, -1, -1}, g, best);
        }
    }

public:
    MPGAA(Graph &g, Node target)
        : Planner(g, target), motions(pose_transitions()), raised(g, WatchedEnd::source, &motions),
          geometric(g.grid.blocked.size(), -1.0) {}

    Result plan(Node start, const Batch &batch, Metrics &m) override {
        if (!batch.clear.empty()) repair(batch, m);
        if (graph.isolated_endpoint(start, goal)) return {};
        ForwardSearch search(start, heuristic(start), m.open);
        std::vector<Node> expanded_poses;
        std::unordered_set<Node> invalid;
        while (!search.empty()) {
            Node u = search.pop();
            Cost g = search.distance(u);
            if (graph.type(u) < 16) {
                Result tail = suffix(u, invalid);
                if (tail.found) {
                    Cost total = g + heuristic(u);
                    for (Node pose : expanded_poses) {
                        Cost bound = total - search.distance(pose);
                        if (heuristic(pose) < bound) {
                            if (learned.try_emplace(pose).second) raised.watch(pose);
                            learned.at(pose).h = bound;
                        }
                    }
                    auto began = Metrics::Clock::now();
                    auto path = search.path(u);
                    Node parent = start;
                    for (const Edge &edge : path) {
                        policy[parent] = edge;
                        parent = edge.node;
                    }
                    if (m.tracing) {
                        // The viewer addresses a mesh route by physical trace steps.
                        for (const Edge &edge : tail.path) m.reused_edges += edge.cost.steps;
                    }
                    path.insert(path.end(), tail.path.begin(), tail.path.end());
                    m.path_ms += Metrics::since(began);
                    return {true, std::move(path)};
                }
                expanded_poses.push_back(u);
            }
            m.expand(graph, u);
            graph.successors(u, successors);
            for (const Edge &edge : successors) {
                if (edge.primitive >= 0) finish_motion(search, edge.node, edge.primitive, g + edge.cost);
                else consider_prefix(search, edge.node, g + edge.cost);
            }
        }
        return {};
    }
};
}

std::unique_ptr<Planner> mpgaa(Graph &g, Node goal) {
    return std::make_unique<MPGAA>(g, goal);
}
